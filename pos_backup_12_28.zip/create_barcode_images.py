import barcode
from barcode.writer import ImageWriter
from barcode.upc import UniversalProductCodeA as upc_a
barcode_data = '123456789012'  # Replace with your scanned data
#
# # Write to a file-like object:
# rv = BytesIO()
# EAN13(str(100000902922), writer=ImageWriter()).write(rv)
#
# # Or to an actual file:
with open("somefile.jpeg", "wb") as f:
    upc_a(barcode_data, writer=ImageWriter()).write(f)

