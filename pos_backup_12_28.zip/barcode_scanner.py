from pynput.keyboard import Key, Listener
import threading
import requests
class BarcodeScanner:
    def __init__(self):
        self.current_barcode = ''
        self.barcode_ready = threading.Event()
        self.listener = Listener(on_press=self.on_press, on_release=self.on_release)
        self.listener.start()

    def on_press(self, key):
        try:
            if key.char is not None:  # Check if the key is alphanumeric
                self.current_barcode += key.char
        except AttributeError:
            pass

    def on_release(self, key):
        if key == Key.enter:
            self.barcode_ready.set()
            self.on_barcode_scanned(self.current_barcode)  # Send barcode to the Flask app
            self.current_barcode = ''  #

    def read_barcode(self):
        self.barcode_ready.wait()  # Wait until barcode is ready (Enter key is pressed)
        barcode = self.current_barcode
        self.current_barcode = ''  # Reset current barcode
        self.barcode_ready.clear()  # Reset the event for the next barcode
        return barcode

    def on_barcode_scanned(self, barcode):
        # Send a POST request to the Flask app
        url = 'http://localhost:5000/barcode-scanned'
        data = {'barcode': barcode}
        try:
            requests.post(url, json=data)
        except requests.RequestException as e:
            print(f"Error sending barcode to server: {e}")


    def close(self):
        self.listener.stop()

# Example usage
if __name__ == "__main__":
    scanner = BarcodeScanner()
    try:
        while True:
            print("Scan a barcode...")
            barcode = scanner.read_barcode()
            if barcode:
                print(f"Scanned barcode: {barcode}")
    except KeyboardInterrupt:
        print("\nExiting barcode scanner.")
    finally:
        scanner.close()
