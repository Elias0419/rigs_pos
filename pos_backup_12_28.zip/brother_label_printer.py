from PIL import Image, ImageDraw, ImageFont
import brother_ql
from brother_ql.conversion import convert
from brother_ql.backends.helpers import send

# Create a basic image with 'Hello World' text
text = "Hello \nWorld"
width, height = 202, 202  # Adjust size according to your label size
font_path = '/usr/share/fonts/TTF/Hack-Bold.ttf'  # Update with the path to your .ttf font
font_size = 50
image = Image.new('L', (width, height), color=255)  # 'L' for black and white
draw = ImageDraw.Draw(image)
font = ImageFont.truetype(font_path, font_size)
draw.text((10, 10), text, font=font, fill=0)

# Save the image if you want to see it
image.save('hello_world_label.png')

# Define the printer model and the backend
model = 'QL-710W'
backend = 'pyusb'  # 'linux_kernel' could also be used
label_type = '23x23'  # Or another as needed
usb_interface = 'usb://0x04F9:0x2043'   # Adjust as necessary

# Create a BrotherQLRaster instance
qlr = brother_ql.BrotherQLRaster(model)
qlr.exception_on_warning = True

# Convert the image to the format the printer understands
convert(qlr=qlr, images=[image], label=label_type)

# Send the data to the printer
send(instructions=qlr.data, printer_identifier=usb_interface, backend_identifier=backend)
