class OrderManager:
    def __init__(self, tax_rate=0.0):
        self.items = []  # List to store items (as dictionaries)
        self.total = 0.0
        self.tax_rate = tax_rate

    def add_item(self, item):
        self.items.append(item)
        self.total += item['price']

    def calculate_total_with_tax(self):
        return self.total * (1 + self.tax_rate)

    def process_payment(self, amount_paid):
        total_with_tax = self.calculate_total_with_tax()
        return max(0, amount_paid - total_with_tax)  # Change to be given

    def clear_order(self):
        self.items = []
        self.total = 0.0

    def get_order_details(self):
        return {
            'items': self.items,
            'total': self.total,
            'total_with_tax': self.calculate_total_with_tax()
        }

# Example usage
if __name__ == "__main__":
    order_manager = OrderManager(tax_rate=0.08)  # 8% tax
    order_manager.add_item({'name': 'Item 1', 'price': 10.00})
    order_manager.add_item({'name': 'Item 2', 'price': 5.00})
    print("Order details:", order_manager.get_order_details())
    print("Change given:", order_manager.process_payment(20.00))  # Customer pays $20
    order_manager.clear_order()
