import pandas as pd

df = pd.read_csv("inventory.csv")
print(len(df))
