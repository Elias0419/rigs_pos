from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.popup import Popup

class CustomKeyboardApp(App):
    def build(self):
        # Main layout for the keyboard
        main_layout = GridLayout(cols=1, spacing=10)

        # Define key groups
        number_keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
        row1_keys = list("QWERTYUIOP")
        row2_keys = list("ASDFGHJKL")
        row3_keys = list("ZXCVBNM")
        special_keys = ["Space", "Confirm/Close"]  # Space and Confirm/Close buttons

        # Function to add keys to a row
        def add_keys_to_layout(layout, keys):
            for key in keys:
                btn = Button(text=key, on_press=self.on_key_press)
                layout.add_widget(btn)

        # Adding rows of keys
        for key_row in [number_keys, row1_keys, row2_keys, row3_keys, special_keys]:
            row_layout = GridLayout(cols=len(key_row))
            add_keys_to_layout(row_layout, key_row)
            main_layout.add_widget(row_layout)

        # Event handler for key presses
        self.text_input = ""  # To store the input text

        return main_layout

    def on_key_press(self, instance):
        if instance.text == "Space":
            self.text_input += " "
        elif instance.text == "Confirm/Close":
            print("Text Entered:", self.text_input)
            # Close the app or popup here
        else:
            self.text_input += instance.text

if __name__ == "__main__":
    CustomKeyboardApp().run()
