

class BarcodeScanner:
    def __init__(self):
        self.current_barcode = ''
        self.barcode_sent = False

    def read_barcode(self):
        print("DEBUG mock_barcode_scanner read_barcode")

        return "12923456789012"

    def is_barcode_ready(self):
        if self.barcode_sent == False:
            self.barcode_sent = True
            return True



if __name__ == "__main__":
    scanner = MockBarcodeScanner()
    try:
        while True:
            print("Scan a barcode...")
            barcode = scanner.read_barcode()
            if barcode:
                print(f"Scanned mock barcode: {barcode}")
                scanner.on_barcode_scanned(barcode)
    except KeyboardInterrupt:
        print("\nExiting mock barcode scanner.")
    finally:
        scanner.close()
