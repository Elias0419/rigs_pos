import os

def count_lines_of_code(directory):
    total_lines = 0
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    total_lines += len(lines)
    return total_lines

# Replace 'your_project_directory_path' with the path to your project directory
project_directory = 'rigs_pos'
lines_count = count_lines_of_code(project_directory)
print(f"Total lines of code in the project: {lines_count}")
