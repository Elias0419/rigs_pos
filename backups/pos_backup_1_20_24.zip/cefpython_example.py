from kivy.app import App
from kivy.uix.widget import Widget
from cefpython3 import cefpython as cef
import sys

class BrowserWidget(Widget):
    def __init__(self, **kwargs):
        super(BrowserWidget, self).__init__(**kwargs)
        self.browser = None
        if sys.platform in ['win32', 'darwin']:
            cef.Initialize()
        self.create_browser()

    def create_browser(self):
        window_info = cef.WindowInfo(self.window_id)
        self.browser = cef.CreateBrowserSync(window_info, url="https://www.example.com")
        cef.MessageLoop()

    def on_parent(self, *args):
        if self.parent is None and self.browser:
            self.browser.CloseBrowser()
            cef.Shutdown()

class MyApp(App):
    def build(self):
        return BrowserWidget()

if __name__ == '__main__':
    MyApp().run()
