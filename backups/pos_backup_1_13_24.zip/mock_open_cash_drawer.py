def open_cash_drawer():
    print("Cash drawer opened")
