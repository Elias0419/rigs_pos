import psutil
import subprocess
import time

def find_process(search_name):
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            cmdline = ' '.join(proc.info['cmdline'])
            if search_name in cmdline:
                print(f"Process found: {proc.info}")
                return proc
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return None

def restart_app(app_name, script_path, python_executable):
    process = find_process(app_name)
    if process:
        process.terminate()
        try:
            process.wait(10)
        except psutil.TimeoutExpired:
            process.kill()

    subprocess.run([python_executable, script_path])
if __name__=="__main__":
    python_executable = '/home/x/work/python/0/bin/python'
    restart_app('python3 kivymd_main_testing.py', '/home/x/work/python/rigs_pos/kivymd_main_testing.py', python_executable)
