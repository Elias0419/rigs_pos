import psutil
import subprocess
import time



def kill_app(pid):

        pid.terminate()
        try:
            pid.wait(10)
        except psutil.TimeoutExpired:
            pid.kill()


if __name__=="__main__":
    python_executable = '/home/x/work/python/0/bin/python'
    restart_app('python3 kivymd_main_testing.py', '/home/x/work/python/rigs_pos/kivymd_main_testing.py', python_executable)
