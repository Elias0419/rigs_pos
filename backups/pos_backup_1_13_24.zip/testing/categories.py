import tkinter as tk
from tkinter import messagebox
import pandas as pd

class CategorizationApp:
    def __init__(self, master, dataframe):
        self.master = master
        self.master.title("Item Categorization")
        self.dataframe = dataframe
        self.current_index = 0
        self.total_items = len(dataframe)
        self.setup_ui()

    def setup_ui(self):
        self.item_label = tk.Label(self.master, text="", font=("Helvetica", 16))
        self.item_label.pack(pady=20)

        self.buttons_frame = tk.Frame(self.master)
        self.buttons_frame.pack(pady=10)

        # Define your categories here
        categories = ["Category 1", "Category 2", "Category 3"]

        for category in categories:
            btn = tk.Button(self.buttons_frame, text=category, command=lambda c=category: self.categorize_item(c))
            btn.pack(side=tk.LEFT, padx=10)

        self.show_next_item()

    def show_next_item(self):
        if self.current_index < self.total_items:
            item_name = self.dataframe.iloc[self.current_index]['Name']
            self.item_label.config(text=item_name)
        else:
            messagebox.showinfo("End", "No more items to categorize")
            self.master.quit()

    def categorize_item(self, category):
        if self.current_index < self.total_items:
            current_item = self.dataframe.iloc[self.current_index]
            current_item['Category'] = category
            self.append_to_csv(current_item)
            self.current_index += 1
            self.show_next_item()

    def append_to_csv(self, item):
        # Append the item to the output CSV
        item.to_frame().T.to_csv('output.csv', mode='a', header=False, index=False)

# Reading the CSV file
df = pd.read_csv('inventory.csv')

# Ensure 'Name' column is present
if 'Name' not in df.columns:
    raise ValueError("CSV must contain a 'Name' column")

# Add a column for Category if not already present
if 'Category' not in df.columns:
    df['Category'] = None

root = tk.Tk()
app = CategorizationApp(root, df)
root.mainloop()

# Save the DataFrame at the end (optional)
df.to_csv('final_output.csv', index=False)
