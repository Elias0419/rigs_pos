import pandas as pd

# Load the CSV file into a DataFrame
file_path = "inventory.csv"
df = pd.read_csv(file_path)

# Checking for duplicates in the 'Product Code' column
duplicates = df[df.duplicated(subset="Product Code", keep=False)].sort_values(
    by="Product Code"
)
print(duplicates)
